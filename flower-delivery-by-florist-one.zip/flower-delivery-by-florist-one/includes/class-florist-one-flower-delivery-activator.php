<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.floristone.com
 * @since      1.0.0
 *
 * @package    Florist_One_Flower_Delivery
 * @subpackage Florist_One_Flower_Delivery/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Florist_One_Flower_Delivery
 * @subpackage Florist_One_Flower_Delivery/includes
 * @author     floristone
 */
class Florist_One_Flower_Delivery_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

		// app has not been previously installed, set defaults
		$options = array(
		  'navigation_color' => '#8db6d9',
		  'navigation_hover_color' => '#18477d',
		  'navigation_text_color' => '#FFF',
		  'navigation_hover_text_color' => '#000',
		  'button_color' => '#8db6d9',
		  'button_hover_color' => '#8db6d9',
		  'button_text_color' => '#FFF',
		  'button_hover_text_color' => '#000',
		  'link_color' => '#18477d',
		  'heading_color' => '#000',
		  'text_color' => '#000',
		  'products_per_page' => 12,
		  'address_institution' => '',
		  'address_1' => '',
		  'address_city' => '',
		  'address_state' => '',
		  'address_zipcode' => '',
		  'address_country' => '',
			'address_phone' => '',
		  'currency' => 'u',
		  'affiliate_id' => '0',
			'flower_storefront_id' => 0,
			'products' => 0,
			'products_cm' => 0,
			'products_ea' => 0,
			'products_md' => 0,
			'products_tg' => 0,
			'products_vd' => 0,
			'products_fb' => 0,
			'rotation' => 0,
			'florists_of_choice' => array(),
			'facility_id' => 0,
			'florist_selection' => 0
		);
		add_option('florist-one-flower-delivery', $options);

		$affiliate_id = '0';

	}

}
