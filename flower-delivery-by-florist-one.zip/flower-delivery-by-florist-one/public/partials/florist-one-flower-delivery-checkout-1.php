<?php
/**
 * @link       https://www.floristone.com
 * @since      1.0.0
 *
 * @package    Florist_One_Flower_Delivery
 * @subpackage Florist_One_Flower_Delivery/public/partials
 */
?>

<h3 class="florist-one-flower-delivery-checkout-heading">Delivery Information</h3>

<form class="checkout-form">

    <?php if($trees == "Trees"){ 
        $prefixTrees = "florist-one-flower-delivery-tree-certificate"; 
        $sections = array('-they-email','-email-behalf');
        $titles = array('I will email the Tree Certificate to the family','Email the Tree Certificate on my behalf');
        $sectionBullets = array(
            array('We will email you a digital copy of Tree Certificate when you have completed checkout.','Choosing this option means you will email the certificate to the family of the deceased.'),
            array('Choosing this option means you will email the certificate to the family of the deceased.','We will also email you the certificate (with the email address you provide on the next page)','You can optionally add a message to the family below.')
        );        
        function createInput($x,$section,$label,$type,$descripton = NULL, $req) {
           $id = $x . $section . "-" . strtolower(str_replace(' ', '-', $label)) ;
           $re = ($req)? "*" : "(500 characters max)";
           echo '<label for="' . $id . '">' . $label . $re . '</label>';
            if ($type != "textarea") {
                echo '<input type="' . $type .'" id="' . $id . '" name="' . $id . '" value="' . $_SESSION[$id] . '">'; 
            } else {
                echo '<textarea id="' . $id . '" name="' . $id . '">' . $_SESSION[$id] .'</textarea>'; 
            }
            if ($descripton != "") { echo '<small>' . $descripton . '</small>';}
          }
        function createLists($text){
            echo '<ul>';  
            for ($list = 0; $list < count($text) ; $list++){echo '<li>' . $text[$list] . '</li>';}
            echo '</ul>';    
        }   
        createInput($prefixTrees, $sections[$z],"Name of Loved One", "text", "The name of your loved one that has passsed. This name will be used in the tree certificate.", true);
        echo '<h4>Select Delivery Method</h4>';
        echo '<div id="' . $prefixTrees . '-wrapper">';
           for($z = 0;$z < 2;$z++){
                $methodSelect = ($_SESSION[$prefixTrees] == "Cert" . $sections[$z]) ? "checked" : "";
                echo '<p class="florist-one-flower-delivery-checkout-heading"><span class="radio-btn-wrapper"><input type="radio" id="' . $prefixTrees . $sections[$z] . '" name="' . $prefixTrees . '" value="Cert' .  $sections[$z] .'"' . $methodSelect . '></span>' .
                     '<label for="'  . $prefixTrees . $sections[$z] . '">' . $titles[$z] . '</label>' .
                     '</p>';
                echo '<div class="trees-checkout">';     
                createLists($sectionBullets[$z]);
                if ($z == 0){//They email
  
                } else {//We email
                    createInput($prefixTrees, $sections[$z],"Recipient Name","text", null, true);
                    createInput($prefixTrees, $sections[$z],"Recipient Email","text","The name and email of the person or family receiving the tree gift and certificate.", true);
                    createInput($prefixTrees, $sections[$z],"Message To Recipient", "textarea", null, false);
                }
                echo '</div>';
            }
        echo '</div>';

    } else { ?>

      <h5>Orders placed now can be delivered on:</h5>  
      <select class="florist-one-flower-delivery-delivery-date full" id="florist-one-flower-delivery-delivery-date" name="florist-one-flower-delivery-delivery-date">
        <?php
          for($i=0;$i<count($delivery_dates['DATES']);$i++){
            if ($delivery_dates['DATES'][$i] == $_SESSION["florist-one-flower-delivery-delivery-date"]){
              echo '<option value="'.$delivery_dates['DATES'][$i].'" selected="selected">'.$delivery_dates['DATES'][$i].' - '.date("l", mktime(0, 0, 0, substr($delivery_dates['DATES'][$i],0,2), substr($delivery_dates['DATES'][$i],3,2), substr($delivery_dates['DATES'][$i],6,4))) .'</option>';
            }
            else{
              echo '<option value="'.$delivery_dates['DATES'][$i].'">'.$delivery_dates['DATES'][$i].' - '.date("l", mktime(0, 0, 0, substr($delivery_dates['DATES'][$i],0,2), substr($delivery_dates['DATES'][$i],3,2), substr($delivery_dates['DATES'][$i],6,4))) .'</option>';
            }
          }
        ?>
      </select>

      <p>&nbsp;</p>

      <h5>Gift Card Message (200 characters max)*</h5>

      <textarea class="florist-one-flower-delivery-card-message" id="florist-one-flower-delivery-card-message" name="florist-one-flower-delivery-card-message"><?php echo $_SESSION["florist-one-flower-delivery-card-message"] ?></textarea>

      <p>Please remember to include who the flowers are from in your message.</p>

      <h5>Optional: Special Delivery Instructions (100 characters max)</h5>

      <textarea class="florist-one-flower-delivery-special-instructions" id="florist-one-flower-delivery-special-instructions" name="florist-one-flower-delivery-special-instructions"><?php echo $_SESSION["florist-one-flower-delivery-special-instructions"] ?></textarea>

      <p>Please enter any information that would help us in the delivery of your order.</p>
  
    <?php } ?>

    <input type="hidden" class="florist-one-flower-delivery-checkout-page" value="<?php echo ($trees == "Trees")? 3:2; ?>">

    <a href="#" class="florist-one-flower-delivery-checkout-continue-checkout large-button">Continue Checkout</a>

</form>
