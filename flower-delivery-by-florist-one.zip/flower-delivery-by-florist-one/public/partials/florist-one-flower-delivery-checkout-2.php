<?php
/**
 * @link       https://www.floristone.com
 * @since      1.0.0
 *
 * @package    Florist_One_Flower_Delivery
 * @subpackage Florist_One_Flower_Delivery/public/partials
 */
?>

<h3>Deliver To</h3>

<?php
  $config_options = get_option('florist-one-flower-delivery');
  if ($config_options['products'] == 0){
    $autopop = 0;
    $delivery_message = 'Please enter the full name of the person to whom the flowers are to be delivered or the name of the deceased for funeral home orders.';
    $location_message = 'Please enter the name of the business, hospital, funeral home or institution if delivery is to be made to a non-residential address. If delivery is to a residence, leave blank.';
  }
  else{
    $autopop = 1;
    $delivery_message = 'Please enter the full name of the deceased.';
    $location_message = 'Please enter the name of the funeral home or service location. If delivery is to a residence, leave blank.';
  }
?>

<form class="checkout-form">

  <table class="florist-one-flower-delivery-review-order full">
    <tr>
      <td><h5>Name*</h5></td>
      <td><input type="text" class="florist-one-flower-delivery-recipient-name" id="florist-one-flower-delivery-recipient-name" name="florist-one-flower-delivery-recipient-name" value="<?php echo $_SESSION["florist-one-flower-delivery-recipient-name"] ?>"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><?php echo $delivery_message; ?></td>
    </tr>

    <?php if(sizeof($config_options['locations']) > 1 && $_SESSION["florist-one-flower-delivery-address-url-params"] == 0) : ?>
    <tr>
      <td><h5>Please select a location</h5></td>
      <td>
        <select class="florist-one-flower-delivery-location full" id="florist-one-flower-delivery-location" name="florist-one-flower-delivery-location" >
          <option></option>
          <?php foreach($config_options['locations'] as $location): ?>
            <option data-location-institution="<?php echo $location->address_institution; ?>" data-location-address-1="<?php echo $location->address_1; ?>" data-location-city="<?php echo $location->address_city; ?>" data-location-state="<?php echo $location->address_state; ?>" data-location-zipcode="<?php echo $location->address_zipcode; ?>" data-location-country="<?php echo $location->address_country; ?>" data-location-phone="<?php echo $location->address_phone; ?>" data-location-facility-id="<?php echo $location->facility_id; ?>" <?php if ($location->address_institution == $_SESSION["florist-one-flower-delivery-recipient-institution"]){ echo "selected=\"selected\""; } ?> ><?php echo $location->address_institution; ?></option>
          <?php endforeach; ?>
        </select>
      </td>
    </tr>
    <?php endif; ?>

    <tr>
      <td><h5>Institution</h5></td>
      <td><input type="text" class="florist-one-flower-delivery-recipient-institution" id="florist-one-flower-delivery-recipient-institution" name="florist-one-flower-delivery-recipient-institution" value="<?php if (empty($_SESSION["florist-one-flower-delivery-recipient-institution"]) && $autopop == 1){ echo $config_options['locations'][0]->address_institution; } else { echo $_SESSION["florist-one-flower-delivery-recipient-institution"]; } ?>"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><?php echo $location_message; ?></td>
    </tr>
    <tr>
      <td><h5>Address*</h5></td>
      <td><input type="text" class="florist-one-flower-delivery-recipient-address-1" id="florist-one-flower-delivery-recipient-address-1" name="florist-one-flower-delivery-recipient-address-1" value="<?php if (empty($_SESSION["florist-one-flower-delivery-recipient-address-1"]) && $autopop == 1){ echo $config_options['locations'][0]->address_1; } else { echo $_SESSION["florist-one-flower-delivery-recipient-address-1"]; } ?>"></td>
    </tr>
    <tr>
      <td><h5>Address 2</h5></td>
      <td><input type="text" class="florist-one-flower-delivery-recipient-address-2" id="florist-one-flower-delivery-recipient-address-2" name="florist-one-flower-delivery-recipient-address-2" value="<?php echo $_SESSION["florist-one-flower-delivery-recipient-address-2"] ?>"></td>
    </tr>
    <tr>
      <td><h5>City*</h5></td>
      <td><input type="text" class="florist-one-flower-delivery-recipient-city" id="florist-one-flower-delivery-recipient-city" name="florist-one-flower-delivery-recipient-city" value="<?php if (empty($_SESSION["florist-one-flower-delivery-recipient-city"]) && $autopop == 1){ echo $config_options['locations'][0]->address_city; } else { echo $_SESSION["florist-one-flower-delivery-recipient-city"]; } ?>"></td>
    </tr>
    <tr>
      <td><h5>State*</h5></td>
      <td>
        <select class="florist-one-flower-delivery-recipient-state full" id="florist-one-flower-delivery-recipient-state" name="florist-one-flower-delivery-recipient-state">
          <?php include 'recipient-state-list.php' ?>
        </select>
      </td>
    </tr>
    <tr>
      <td><h5>Country*</h5></td>
      <td>
        <select class="florist-one-flower-delivery-recipient-country full" id="florist-one-flower-delivery-recipient-country" name="florist-one-flower-delivery-recipient-country">
          <option value='US' <?php if (empty($_SESSION["florist-one-flower-delivery-recipient-country"]) && $autopop == 1){ echo ($config_options['locations'][0]->address_country=='US'? 'selected="selected"' : '' );; } else { echo ($_SESSION['florist-one-flower-delivery-recipient-country']=='US'? 'selected="selected"' : '' ); } ?>>United States</option>
          <option value='CA' <?php if (empty($_SESSION["florist-one-flower-delivery-recipient-country"]) && $autopop == 1){ echo ($config_options['locations'][0]->address_country=='CA'? 'selected="selected"' : '' );; } else { echo ($_SESSION['florist-one-flower-delivery-recipient-country']=='CA'? 'selected="selected"' : '' ); } ?>>Canada</option>
        </select>
      </td>
    </tr>
    <tr>
      <td><h5>Zip Code / Postal Code*</h5></td>
      <td><input type="text" class="florist-one-flower-delivery-recipient-postal-code" id="florist-one-flower-delivery-recipient-postal-code" name="florist-one-flower-delivery-recipient-postal-code" value="<?php if (empty($_SESSION["florist-one-flower-delivery-recipient-postal-code"]) && $autopop == 1){ echo $config_options['locations'][0]->address_zipcode; } else { echo $_SESSION["florist-one-flower-delivery-recipient-postal-code"]; } ?>"></td>
    </tr>
    <tr>
      <td><h5>Phone</h5></td>
      <td><input type="text" class="florist-one-flower-delivery-recipient-phone" id="florist-one-flower-delivery-recipient-phone" name="florist-one-flower-delivery-recipient-phone" value="<?php if (empty($_SESSION["florist-one-flower-delivery-recipient-phone"]) && $autopop == 1){ echo $config_options['locations'][0]->address_phone; } else { echo $_SESSION["florist-one-flower-delivery-recipient-phone"]; } ?>"></td>
    </tr>
  </table>

  <input type="hidden" class="florist-one-flower-delivery-facility-id" id="florist-one-flower-delivery-facility-id" name="florist-one-flower-delivery-facility-id" value="<?php if (empty($_SESSION["florist-one-flower-delivery-facility-id"]) && sizeof($config_options['locations']) == 1){ echo $config_options['locations'][0]->facility_id; } else if (empty($_SESSION["florist-one-flower-delivery-facility-id"])){ echo "0"; } else { echo $_SESSION["florist-one-flower-delivery-facility-id"]; } ?>">

  <input type="hidden" class="florist-one-flower-delivery-checkout-page" value="3">

  <a href="#" class="florist-one-flower-delivery-checkout-continue-checkout large-button">Continue Checkout</a>

</form>
