<?php
/**
 * @link       https://www.floristone.com
 * @since      1.0.0
 *
 * @package    Florist_One_Flower_Delivery
 * @subpackage Florist_One_Flower_Delivery/public/partials
 */
?>

<p class="florist-one-flower-delivery-review-error-message" style="display: none; color: red; text-align: center;">Please correct the fields in red below and then click on 'Process Order'.</p>

<h3 class="florist-one-flower-delivery-checkout-heading">Review Your Order</h3>

<?php $dont_show_remove_button=1 ?>

<table class="florist-one-flower-delivery-review-order half">
  <?php 
    function createRow($label,$info,$tree){
      $section = substr($_SESSION['florist-one-flower-delivery-tree-certificate'], 5) . "-";
      $class = "";
      $display = "";
      if ($label == "edit button"){ // edit button
        $edit_page = ($tree)? "1" : "2"; // page to go for edit
        $type =  ($tree)? "Trees" : "Flower";
        $label = '<a href="#" id="florist-one-flower-delivery-checkout-page-edit-' . $edit_page . '" class="florist-one-flower-delivery-checkout-page-edit" data-page="' . $edit_page .'" data-edit-type="' . $type .'">Edit</a>';
      } else {
        if (is_array($label)){ // check if more than one label
          for ($x =0; $x < count($label);$x++){
            $seperate = ($x == 0) ? ", " : " ";
            $display .= $_SESSION["florist-one-flower-delivery-recipient-" . strtolower(str_replace(' ', '-', $label[$x]))] . $seperate ;
          }
          $class = "florist-one-flower-delivery-review-recipient-" . $label[0];
          $label = "";
        } else { // only one label
          $field =  strtolower(str_replace(' ', '-', $label));
          $id = ($tree)? "florist-one-flower-delivery-tree-certificate-" . $section . $field : "florist-one-flower-delivery-recipient-" . $field;
          if ($label == "Name of Loved One"){
            $id = "florist-one-flower-delivery-tree-certificate-" . $field;
          }
          if ($label == "Delivery Method") {
            $display = ($section == "they-email-") ? "You Email Certificate" : "We Email Certificate";
          } else {
            $display = ($info)? $_SESSION[$id] : "&nbsp;";
          }
          $class = ($info)? ($tree) ?"florist-one-flower-delivery-review-tree-certificate-" . $section .  $field : "florist-one-flower-delivery-review-recipient-" . $field : "";
        }      
      }
      $colon = ($label == "")? "" : ($info)?":":"";
      echo '<tr><td' . (($info)? '': ' colspan="2"') .'>' . $label . $colon . '</td>';
      if ($info){ echo '<td class ="' . $class . '">' . $display . '</td></tr>';}
    }
    if ( $_SESSION['florist-one-flower-delivery-tree-certificate'] != ""){// do if plant a tree
      $section = substr($_SESSION['florist-one-flower-delivery-tree-certificate'], 5);
      createRow("<span class='florist-one-flower-delivery-review-section'>Tree Certificate Information</span>",false,true);
      createRow("Delivery Method",true,true);
      if ($section == "they-email") { 
        createRow("Name of Loved One",true,true);
      } else { 
        createRow("Name of Loved One",true,true);
        createRow("Recipient Name",true,true);
        createRow("Recipient Email",true,true);
        createRow("Message To Recipient",true,true);
      }
      createRow('edit button',false, true);
    } else { // do if not plant a tree 
      createRow("<span class='florist-one-flower-delivery-review-section'>Deliver To</span>", false,false);
      $deliver_to_fields = array("Name","Institution","Address 1","Address 2",array('city','state','postal code'),"Phone");
      for ($d = 0; $d < count($deliver_to_fields);$d++){
        createRow($deliver_to_fields[$d], true,false);
      }
      createRow('edit button',false, false);
    } ?>
</table>

<table class="florist-one-flower-delivery-review-order half">
  <?php  
    function createRowBillTo($label){// bill to table
      $field = strtolower(str_replace(' ', '-', $label));
      $prefix = 'florist-one-flower-delivery-customer-';//field
      $stylePre = 'florist-one-flower-delivery-review-customer-';//class
      $id = $prefix . $field;
      if (is_array($label)){ // check if more than one label
        for ($x =0; $x < count($label);$x++){
          $seperate = ($x == 0) ? ", " : " ";
          $display .= $_SESSION[$prefix . strtolower(str_replace(' ', '-', $label[$x]))] . $seperate ;
        }
        $class = $stylePre . $label[0];
        $label = "";
      } else {//only one label
         $display = $_SESSION[$id];
         $class = $stylePre . $field;
      }
      echo '<tr><td>' . $label . ($label == "" ? "":":") . '</td><td class="' . $class . '">' . $display . '</td></tr>';
    }
    createRow("<span class='florist-one-flower-delivery-review-section'>Bill To</span>",false,false);
    $bill_fields = array("Name", "Address 1", "Address 2", array('City','State','Postal Code'), "Phone","Email");
    for ($f = 0; $f < count($bill_fields);$f++){
      createRowBillTo($bill_fields[$f]);
    }
    createRow('<a href="#" id="florist-one-flower-delivery-checkout-page-edit-3" class="florist-one-flower-delivery-checkout-page-edit" data-page="3">Edit</a>',false,false);
  ?>  
</table>

<?php if ($_SESSION['florist-one-flower-delivery-tree-certificate'] == ""){ // don't show if plant a tree ?>

  <table class="florist-one-flower-delivery-review-order full">
    <tr>
      <td><span class='florist-one-flower-delivery-review-section'>Gift Card Message</span></td>
    </tr>
    <tr>
      <td class="florist-one-flower-delivery-review-card-message"><?php echo $_SESSION['florist-one-flower-delivery-card-message'] ?></td>
    </tr>
    <tr>
      <td>
        <a href="#" id="florist-one-flower-delivery-checkout-page-edit-1" class="florist-one-flower-delivery-checkout-page-edit" data-page="1">Edit</a>
      </td>
    </tr>
  </table>

  <table class="florist-one-flower-delivery-review-order full">
    <tr>
      <td><span class='florist-one-flower-delivery-review-section'>Special Instructions</span></td>
    </tr>
    <tr>
      <td class="florist-one-flower-delivery-review-special-instructions"><?php echo $_SESSION['florist-one-flower-delivery-special-instructions'] ?></td>
    </tr>
    <tr>
      <td>
        <a href="#" id="florist-one-flower-delivery-checkout-page-edit-1-3" class="florist-one-flower-delivery-checkout-page-edit" data-page="1">Edit</a>
      </td>
    </tr>

  </table>

  <table class="florist-one-flower-delivery-review-order full">
    <tr>
      <td><span class='florist-one-flower-delivery-review-section'>Delivery Date</span></td>
    </tr>
    <tr>
      <td class="florist-one-flower-delivery-review-delivery-date"><?php echo $_SESSION['florist-one-flower-delivery-delivery-date'] ?></td>
    </tr>
    <tr>
      <td>
        <a href="#" id="florist-one-flower-delivery-checkout-page-edit-1-2" class="florist-one-flower-delivery-checkout-page-edit" data-page="1">Edit</a>
      </td>
    </tr>
  </table>


<?php }  ?>


<?php
  
  if(count($products_for_display) != 0){
  
    include 'florist-one-flower-delivery-cart-body.php';
  
  }
  
  if(count($products_for_display) > 0){
  
    $amount = number_format($get_total_response_body['ORDERTOTAL'], 2);
    $redirect_url = $_SERVER['HTTP_REFERER'];  
    $treeDeliveryMethod = $_SESSION['florist-one-flower-delivery-tree-certificate'];
    $config_options = get_option('florist-one-flower-delivery');
    
    $products = array();
   
    // check for trees
    if ($products_for_display[0]['CODE'] == "TREE"){ // just for trees
       $customer = array(
        'first_name' => $_SESSION['florist-one-flower-delivery-customer-name'],
        'last_name' => "",
        'address' => $_SESSION['florist-one-flower-delivery-customer-address-1'] . " " . $_SESSION['florist-one-flower-delivery-customer-address-2'] ,
        'city' => $_SESSION['florist-one-flower-delivery-customer-city'],
        'state' => $_SESSION['florist-one-flower-delivery-customer-state'],
        'zipcode' => $_SESSION['florist-one-flower-delivery-customer-postal-code'],
        'country' => $_SESSION['florist-one-flower-delivery-customer-country'],
        'phone' => $_SESSION['florist-one-flower-delivery-customer-phone'],
        'email' => $_SESSION['florist-one-flower-delivery-customer-email'],
        'ip' => $_SERVER['REMOTE_ADDR']
      );
      $recipient = array(
        'message' => ($treeDeliveryMethod == "Cert-email-behalf") ? $_SESSION['florist-one-flower-delivery-tree-certificate-email-behalf-message-to-recipient'] : "",
        'first_name' => ($treeDeliveryMethod == "Cert-email-behalf") ?$_SESSION['florist-one-flower-delivery-tree-certificate-email-behalf-recipient-name'] : "",
        'last_name' => "",
        'email' => ($treeDeliveryMethod == "Cert-email-behalf") ? $_SESSION['florist-one-flower-delivery-tree-certificate-email-behalf-recipient-email']:"",
        'send_certificate' => ($treeDeliveryMethod == "Cert-email-behalf") ? 1 : 0
      );
        $product = array(
            'code' => $products_for_display[0]['CODE'],
            'amount' => $products_for_display[0]['PRICE'],
            'number' =>    intval(preg_replace('/[^0-9.]+/', '', $vars["products"][0]["NAME"])),
          );
    } else { // all but trees
    
       $customer = array(
        'name' => $_SESSION["florist-one-flower-delivery-customer-name"],
        'address1' => $_SESSION["florist-one-flower-delivery-customer-address-1"],
        'address2' => $_SESSION["florist-one-flower-delivery-customer-address-2"],
        'city' => $_SESSION["florist-one-flower-delivery-customer-city"],
        'state' => $_SESSION["florist-one-flower-delivery-customer-state"],
        'zipcode' => $_SESSION["florist-one-flower-delivery-customer-postal-code"],
        'country' => $_SESSION["florist-one-flower-delivery-customer-country"],
        'email' => $_SESSION["florist-one-flower-delivery-customer-email"],
        'phone' => $_SESSION["florist-one-flower-delivery-customer-phone"],
        'ip' => $_SERVER['REMOTE_ADDR']
      );
      $recipient = array(
        'name' => $_SESSION["florist-one-flower-delivery-recipient-name"],
        'institution' => $_SESSION['florist-one-flower-delivery-recipient-institution'],
        'address1' => $_SESSION["florist-one-flower-delivery-recipient-address-1"],
        'address2' => $_SESSION["florist-one-flower-delivery-recipient-address-2"],
        'city' => $_SESSION["florist-one-flower-delivery-recipient-city"],
        'state' => $_SESSION["florist-one-flower-delivery-recipient-state"],
        'zipcode' => $_SESSION["florist-one-flower-delivery-recipient-postal-code"],
        'country' => $_SESSION["florist-one-flower-delivery-recipient-country"],
        'phone' => $_SESSION["florist-one-flower-delivery-recipient-phone"]
      );
     
      for ($i=0;$i<count($products_for_display);$i++){
        array_push(
          $products,
          array(
            'code' => $products_for_display[$i]['CODE'],
            'price' => $products_for_display[$i]['PRICE'],
            'recipient' => $recipient,
            'deliverydate' => $_SESSION["florist-one-flower-delivery-delivery-date"],
            'cardmessage' => $_SESSION["florist-one-flower-delivery-card-message"],
            'specialinstructions' => $_SESSION["florist-one-flower-delivery-special-instructions"]
          )
        );
      }
    }
    if ($products_for_display[0]['CODE'] == "TREE"){//payload for Tree
      
      $payload = array(
        'customer' => $customer,
        'recipient' => $recipient,
        'product' => $product,
        'facilityid' => $_SESSION["florist-one-flower-delivery-facility-id"],
        'referring_affiliate_id' => $config_options["affiliate_id"],
        'f1_storefront_id' => $config_options["flower_storefront_id"],
        'deceased_display_name' => $_SESSION["florist-one-flower-delivery-tree-certificate-name-of-loved-one"],
        'apikey' => USERNAME
      );
    
    
    } else {
    
      $payload = array(
        'customer' => $customer,
        'products' => $products,
        'facilityid' => $_SESSION["florist-one-flower-delivery-facility-id"],
        'f1_aff_id' => $config_options["affiliate_id"],
        'f1_storefront_id' => $config_options["flower_storefront_id"],
        'apikey' => USERNAME
      );
    
    }
    error_log( print_r("info stuff", true ) );
    error_log( print_r($vars["products"], true ) );
    error_log( print_r($amount, true ) );
    error_log( print_r($payload, true ) );
    
    $fingerprint = createAuthorizeNetHostedForm($amount, $redirect_url, $payload);
    

    echo '<form method="post" action="https://accept.authorize.net/payment/payment">';

    echo '<input type="hidden" name="token" value="' . $fingerprint['body']['token'] . '" />';

    echo '<input type="submit" class="large-button" value="Continue To Payment Gateway" />';

    echo '</form>';

  }
  else{
    echo '<table><tr><td><h5>Shopping Cart</h5></td></tr><tr><td>Your shopping cart is empty.</td></tr></table>';
  }

?>


  <?php if (!(isset($fingerprint["errors"]))) : ?>
    <script>
      var w = 800;
      var h = 800;

      var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : screen.left;
      var dualScreenTop = window.screenTop != undefined ? window.screenTop : screen.top;

      var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
      var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;

      var left = ((width / 2) - (w / 2)) + dualScreenLeft;
      var top = ((height / 2) - (h / 2)) + dualScreenTop;

      function checkWindow() {
          if (childWindow && childWindow.closed) {
              window.clearInterval(intervalID);
              jQuery(".child_window_closed").trigger("click");
          }
      }

      if (typeof childWindow !== 'undefined'){
        delete childWindow;
      }
    </script>
  <?php else : ?>
    <script>

      var errors = jQuery.parseJSON(jQuery("input.errors").val());

      if (errors.length > 0){
        $(".florist-one-flower-delivery-review-error-message").css("display","block");
      }

      for(i=0;i<errors.length;i++){
        if (errors[i].substr(0, 21) == 'invalid delivery date'){
          jQuery(".florist-one-flower-delivery-review-delivery-date").css("color", "red");
        }
        else if (errors[i].substr(0, 11) == 'cardmessage'){
          jQuery(".florist-one-flower-delivery-review-card-message").css("color", "red");
        }
        else if (errors[i].substr(0, 19) == 'specialinstructions'){
          jQuery(".florist-one-flower-delivery-review-special-instructions").css("color", "red");
        }
        else if (errors[i].substr(0, 14) == 'recipient name'){
          jQuery(".florist-one-flower-delivery-review-recipient-name").css("color", "red");
        }
        else if (errors[i].substr(0, 21) == 'recipient institution'){
          jQuery(".florist-one-flower-delivery-review-recipient-institution").css("color", "red");
        }
        else if (errors[i].substr(0, 18) == 'recipient address1'){
          jQuery(".florist-one-flower-delivery-review-recipient-address-1").css("color", "red");
        }
        else if (errors[i].substr(0, 18) == 'recipient address2'){
          jQuery(".florist-one-flower-delivery-review-recipient-address-2").css("color", "red");
        }
        else if (errors[i].substr(0, 14) == 'recipient city'){
          jQuery(".florist-one-flower-delivery-review-recipient-city").css("color", "red");
        }
        else if (errors[i].substr(0, 15) == 'recipient state'){
          jQuery(".florist-one-flower-delivery-review-recipient-city").css("color", "red");
        }
        else if (errors[i].substr(0, 17) == 'recipient country'){
          jQuery(".florist-one-flower-delivery-review-recipient-country").css("color", "red");
        }
        else if (errors[i].substr(0, 15) == 'recipient phone'){
          jQuery(".florist-one-flower-delivery-review-recipient-phone").css("color", "red");
        }
        else if (errors[i].substr(0, 17) == 'recipient zipcode'){
          jQuery(".florist-one-flower-delivery-review-recipient-city").css("color", "red");
        }
        else if (errors[i].substr(0, 13) == 'customer name'){
          jQuery(".florist-one-flower-delivery-review-customer-name").css("color", "red");
        }
        else if (errors[i].substr(0, 17) == 'customer address1'){
          jQuery(".florist-one-flower-delivery-review-customer-address-1").css("color", "red");
        }
        else if (errors[i].substr(0, 17) == 'customer address2'){
          jQuery(".florist-one-flower-delivery-review-customer-address-2").css("color", "red");
        }
        else if (errors[i].substr(0, 13) == 'customer city'){
          jQuery(".florist-one-flower-delivery-review-customer-city").css("color", "red");
        }
        else if (errors[i].substr(0, 14) == 'customer state'){
          jQuery(".florist-one-flower-delivery-review-customer-city").css("color", "red");
        }
        else if (errors[i].substr(0, 16) == 'customer country'){
          jQuery(".florist-one-flower-delivery-review-customer-country").css("color", "red");
        }
        else if (errors[i].substr(0, 14) == 'customer phone'){
          jQuery(".florist-one-flower-delivery-review-customer-phone").css("color", "red");
        }
        else if (errors[i].substr(0, 16) == 'customer zipcode'){
          jQuery(".florist-one-flower-delivery-review-customer-city").css("color", "red");
        }
        else if (errors[i].substr(0, 14) == 'customer email'){
          jQuery(".florist-one-flower-delivery-review-customer-email").css("color", "red");
        }
        else{
          alert(errors[i]);
        }
      }

      jQuery("#authnet_form").submit(function( event ) {
          event.preventDefault();
          alert( "Please correct fields marked in red before continuing to payment" );
      });


    </script>
  <?php endif; ?>
