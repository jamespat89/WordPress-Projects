<optgroup label="United States">
  <option value="AL" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='AL'? 'selected="selected"' : '' ) ?>>Alabama</option>
  <option value="AK" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='AK'? 'selected="selected"' : '' ) ?>>Alaska</option>
  <option value="AZ" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='AZ'? 'selected="selected"' : '' ) ?>>Arizona</option>
  <option value="AR" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='AR'? 'selected="selected"' : '' ) ?>>Arkansas</option>
  <option value="CA" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='CA'? 'selected="selected"' : '' ) ?>>California</option>
  <option value="CO" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='CO'? 'selected="selected"' : '' ) ?>>Colorado</option>
  <option value="CT" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='CT'? 'selected="selected"' : '' ) ?>>Connecticut</option>
  <option value="DE" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='DE'? 'selected="selected"' : '' ) ?>>Delaware</option>
  <option value="DC" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='DC'? 'selected="selected"' : '' ) ?>>District Of Columbia</option>
  <option value="FL" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='FL'? 'selected="selected"' : '' ) ?>>Florida</option>
  <option value="GA" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='GA'? 'selected="selected"' : '' ) ?>>Georgia</option>
  <option value="HI" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='HI'? 'selected="selected"' : '' ) ?>>Hawaii</option>
  <option value="ID" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='ID'? 'selected="selected"' : '' ) ?>>Idaho</option>
  <option value="IL" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='IL'? 'selected="selected"' : '' ) ?>>Illinois</option>
  <option value="IN" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='IN'? 'selected="selected"' : '' ) ?>>Indiana</option>
  <option value="IA" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='IA'? 'selected="selected"' : '' ) ?>>Iowa</option>
  <option value="KS" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='KS'? 'selected="selected"' : '' ) ?>>Kansas</option>
  <option value="KY" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='KY'? 'selected="selected"' : '' ) ?>>Kentucky</option>
  <option value="LA" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='LA'? 'selected="selected"' : '' ) ?>>Louisiana</option>
  <option value="ME" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='ME'? 'selected="selected"' : '' ) ?>>Maine</option>
  <option value="MD" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='MD'? 'selected="selected"' : '' ) ?>>Maryland</option>
  <option value="MA" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='MA'? 'selected="selected"' : '' ) ?>>Massachusetts</option>
  <option value="MI" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='MI'? 'selected="selected"' : '' ) ?>>Michigan</option>
  <option value="MN" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='MS'? 'selected="selected"' : '' ) ?>>Minnesota</option>
  <option value="MS" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='MN'? 'selected="selected"' : '' ) ?>>Mississippi</option>
  <option value="MO" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='MO'? 'selected="selected"' : '' ) ?>>Missouri</option>
  <option value="MT" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='MT'? 'selected="selected"' : '' ) ?>>Montana</option>
  <option value="NE" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NE'? 'selected="selected"' : '' ) ?>>Nebraska</option>
  <option value="NV" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NV'? 'selected="selected"' : '' ) ?>>Nevada</option>
  <option value="NH" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NH'? 'selected="selected"' : '' ) ?>>New Hampshire</option>
  <option value="NJ" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NJ'? 'selected="selected"' : '' ) ?>>New Jersey</option>
  <option value="NM" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NM'? 'selected="selected"' : '' ) ?>>New Mexico</option>
  <option value="NY" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NY'? 'selected="selected"' : '' ) ?>>New York</option>
  <option value="NC" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NC'? 'selected="selected"' : '' ) ?>>North Carolina</option>
  <option value="ND" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='ND'? 'selected="selected"' : '' ) ?>>North Dakota</option>
  <option value="OH" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='OH'? 'selected="selected"' : '' ) ?>>Ohio</option>
  <option value="OK" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='OK'? 'selected="selected"' : '' ) ?>>Oklahoma</option>
  <option value="OR" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='OR'? 'selected="selected"' : '' ) ?>>Oregon</option>
  <option value="PA" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='PA'? 'selected="selected"' : '' ) ?>>Pennsylvania</option>
  <option value="RI" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='RI'? 'selected="selected"' : '' ) ?>>Rhode Island</option>
  <option value="SC" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='SC'? 'selected="selected"' : '' ) ?>>South Carolina</option>
  <option value="SD" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='SD'? 'selected="selected"' : '' ) ?>>South Dakota</option>
  <option value="TN" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='TN'? 'selected="selected"' : '' ) ?>>Tennessee</option>
  <option value="TX" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='TX'? 'selected="selected"' : '' ) ?>>Texas</option>
  <option value="UT" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='UT'? 'selected="selected"' : '' ) ?>>Utah</option>
  <option value="VT" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='VT'? 'selected="selected"' : '' ) ?>>Vermont</option>
  <option value="VA" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='VA'? 'selected="selected"' : '' ) ?>>Virginia</option>
  <option value="WA" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='WA'? 'selected="selected"' : '' ) ?>>Washington</option>
  <option value="WV" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='WV'? 'selected="selected"' : '' ) ?>>West Virginia</option>
  <option value="WI" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='WI'? 'selected="selected"' : '' ) ?>>Wisconsin</option>
  <option value="WY" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='WY'? 'selected="selected"' : '' ) ?>>Wyoming</option>
</optgroup>
<optgroup label="Canada">
  <option value="AB" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='AB'? 'selected="selected"' : '' ) ?>>Alberta</option>
  <option value="BC" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='BC'? 'selected="selected"' : '' ) ?>>British Columbia</option>
  <option value="MB" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='MB'? 'selected="selected"' : '' ) ?>>Manitoba</option>
  <option value="NB" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NB'? 'selected="selected"' : '' ) ?>>New Brunswick</option>
  <option value="NL" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NL'? 'selected="selected"' : '' ) ?>>Newfoundland and Labrador</option>
  <option value="NS" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NS'? 'selected="selected"' : '' ) ?>>Nova Scotia</option>
  <option value="ON" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='ON'? 'selected="selected"' : '' ) ?>>Ontario</option>
  <option value="PE" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='PE'? 'selected="selected"' : '' ) ?>>Prince Edward Island</option>
  <option value="QC" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='QC'? 'selected="selected"' : '' ) ?>>Quebec</option>
  <option value="SK" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='SK'? 'selected="selected"' : '' ) ?>>Saskatchewan</option>
  <option value="NT" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NT'? 'selected="selected"' : '' ) ?>>Northwest Territories</option>
  <option value="NU" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='NU'? 'selected="selected"' : '' ) ?>>Nunavut</option>
  <option value="YT" <?php echo ($_SESSION['florist-one-flower-delivery-customer-state']=='YT'? 'selected="selected"' : '' ) ?>>Yukon</option>
</optgroup>
