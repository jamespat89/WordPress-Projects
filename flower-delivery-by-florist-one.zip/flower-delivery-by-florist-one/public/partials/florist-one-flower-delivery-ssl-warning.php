<?php
$config_options = get_option('florist-one-flower-delivery');

if ($config_options['affiliate_id'] == 0){
  echo '<div class="florist-one-flower-delivery-ssl-warning">&#9888; A valid Florist One AffiliateID is required for the Florist One Flower Delivery plugin to work!</div>';
}

?>
