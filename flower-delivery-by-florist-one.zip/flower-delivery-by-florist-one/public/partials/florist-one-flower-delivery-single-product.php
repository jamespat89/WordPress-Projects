<?php
/**
 * @link       https://www.floristone.com
 * @since      1.0.0
 *
 * @package    Florist_One_Flower_Delivery
 * @subpackage Florist_One_Flower_Delivery/public/partials
 */
?>

<h3 class="florist-one-flower-delivery-single-product-name-high"><?php echo $api_response_body['itemName'] ?></h3>

<div class="florist-one-flower-delivery-single-product">
  <p class="center"><img src=" <?php echo $api_response_body['PRODUCTS'][0]['LARGE'] ?>" /></p>
</div>

<div class="florist-one-flower-delivery-single-product">
  <?php  if ($code != 'TREE') { ?>
    <p class="center"><a href="#" class="florist-one-flower-delivery-add-to-cart florist-one-flower-delivery-button center" id="florist-one-flower-delivery-add-to-cart-<?php echo $api_response_body['PRODUCTS'][0]['CODE'] ?>-1" data-code="<?php echo $api_response_body['PRODUCTS'][0]['CODE'] ?>">Add To Cart</a></p>
  <?php } ?>
  <p>&nbsp;</p>
  <h3 class="florist-one-flower-delivery-single-product-name-low"><?php echo $api_response_body['PRODUCTS'][0]['NAME'] ?></h3>
  <p class="florist-one-flower-delivery-single-product-description"><?php echo $api_response_body['PRODUCTS'][0]['DESCRIPTION'] ?></p>

<?php 

if ($code == 'TREE') { ?>

    <div id="florist-one-flower-delivery-plant-a-tree-container">

        <h3>A Group of Five Trees</h3>
        
        <div class="florist-one-flower-delivery-plant-a-tree-select">
            <table id="florist-one-flower-delivery-plant-a-tree-select-from">
            <tbody>
            
                <?php
            
                for ($x = 0; $x <= 0; $x++) { ?>
                    <!-- change $x <= 2 for other options -->
                    <tr>
                        <td><input type="radio" data-price='<?php echo $api_response_body['Group' . ($x + 1) .'Pricing']['price'] ?>' data-name="<?php echo $api_response_body['Group' . ($x + 1) .'Pricing']['displayText'] ?>" name="florist-one-flower-delivery-plant-a-tree-select-from-number" value="<?php echo preg_replace('/[^0-9]/', '',$api_response_body['Group' . ($x + 1) .'Pricing']['displayText'])?>" <?php if ($x == 0){echo 'checked="checked"';} ?>></td>
                        <td class="group_of"><?php echo $api_response_body['Group' . ($x + 1) .'Pricing']['displayText'] ?></td>
                        <td>-&nbsp;&nbsp;$<?php echo number_format( $api_response_body['Group' . ($x + 1) .'Pricing']['price'], 2, '.', '') ?></td>
                    </tr>
                <?php } ?>

            </tbody></table>
            
        <p class="florist-one-flower-delivery-single-product-price">$<?php echo number_format( $api_response_body['PRODUCTS'][0]['PRICE'], 2, '.', '')?></p>
        </div>
        <p><a href="#" class="florist-one-flower-delivery-add-to-cart florist-one-flower-delivery-button" id="plant-a-tree-add-to-cart1" data-name="<?php echo $api_response_body['Group1Pricing']['displayText'] ?>" data-code="<?php echo $api_response_body['Group1Pricing']['displayText'] ?>" data-price="<?php echo $api_response_body['PRODUCTS'][0]['PRICE'] ?>" data-number="5">Add To Cart</a></p>

    
        <h3>Select Your Own Number of Trees</h3>
        <div class="florist-one-flower-delivery-plant-a-tree-select">
            <p><input id="florist-one-flower-delivery-plant-a-tree-select-your-own" name="florist-one-flower-delivery-plant-a-tree-select-your-own" type="number" min="5"> 
            <a href="#" class="florist-one-flower-delivery-plant-a-tree-select-your-own-calculate florist-one-flower-delivery-button" id="florist-one-flower-delivery-add-to-cart-<?php echo $api_response_body['PRODUCTS'][0]['CODE'] ?>-2" data-code="<?php echo $api_response_body['PRODUCTS'][0]['CODE'] ?>">Calculate Price</a></p>
            
            <div id="calculate-msg"></div>
        </div>
    </div>
<?php } else {?>

    <p class="florist-one-flower-delivery-single-product-price">$<?php echo $api_response_body['PRODUCTS'][0]['PRICE'] ?></p>
    <p>&nbsp;</p>
    <p class="center"><a href="#" class="florist-one-flower-delivery-add-to-cart florist-one-flower-delivery-button center" id="florist-one-flower-delivery-add-to-cart-<?php echo $api_response_body['PRODUCTS'][0]['CODE'] ?>-2" data-code="<?php echo $api_response_body['PRODUCTS'][0]['CODE'] ?>">Add To Cart</a></p>


<?php } ?>


</div>
